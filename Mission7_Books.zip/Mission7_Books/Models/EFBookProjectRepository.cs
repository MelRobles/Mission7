﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mission7_Books.Models
{
    public class EFBookProjectRepository : IBookProjectRepository
    {
        private BookstoreContext context { get; set; }

        //constructor
        public EFBookProjectRepository (BookstoreContext temp)
        {
            context = temp;
        }
        
        public IQueryable<Book> Books => context.Books;
    }
}
